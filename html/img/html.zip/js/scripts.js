$(window).on('load', function(event) {
	var ap = true, aus = 2000;
	$('.sl-1').slick({
		autoplay:ap,
		 autoplaySpeed: aus,
		arrows:false,
		asNavFor: '.sl-nav-sl1'
	})
	$('.sl-nav-sl1').slick({
		autoplay:ap,
		 autoplaySpeed: aus,
		asNavFor: '.sl-1',
		slidesToShow: 3,
		slidesToScroll: 1,
		prevArrow:'<button type="button" class="slick-prev"><i class="icon-left-open"></i></button>',
		nextArrow:'<button type="button" class="slick-next"><i class="icon-right-open"></i></button>',
		responsive: [
			{
			  breakpoint: 768,
			  settings: {
				arrows:false
			  }
			}
		]
	})
	$('.slick.docs').slick({
		autoplay:ap,
		 autoplaySpeed: aus,
		slidesToShow: 4,
		slidesToScroll: 1,
		prevArrow:'<button type="button" class="slick-prev"><i class="icon-left-open"></i></button>',
		nextArrow:'<button type="button" class="slick-next"><i class="icon-right-open"></i></button>',
		responsive: [
			{
			  breakpoint: 1200,
			  settings: {
				slidesToShow: 3,
				slidesToScroll: 1,
			  }
			},
			{
			  breakpoint: 991,
			  settings: {
				slidesToShow: 2,
				slidesToScroll: 1
			  }
			},
			{
			  breakpoint: 767,
			  settings: {
				slidesToShow: 2,
				slidesToScroll: 1
			  }
			},
			{
			  breakpoint: 480,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1
			  }
			}
			// You can unslick at a given breakpoint now by adding:
			// settings: "unslick"
			// instead of a settings object
		  ]
	})
	$('.slick.logs').slick({
		autoplay:ap,
		 autoplaySpeed: aus,
		slidesToShow: 4,
		slidesToScroll: 1,
		prevArrow:'<button type="button" class="slick-prev"><i class="icon-left-open"></i></button>',
		nextArrow:'<button type="button" class="slick-next"><i class="icon-right-open"></i></button>',
		responsive: [
			{
			  breakpoint: 1200,
			  settings: {
				slidesToShow: 3,
				slidesToScroll: 1,
			  }
			},
			{
			  breakpoint: 991,
			  settings: {
				slidesToShow: 2,
				slidesToScroll: 1
			  }
			},
			{
			  breakpoint: 767,
			  settings: {
				slidesToShow: 2,
				slidesToScroll: 1
			  }
			},
			{
			  breakpoint: 480,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1
			  }
			}
			// You can unslick at a given breakpoint now by adding:
			// settings: "unslick"
			// instead of a settings object
		  ]
	})
	$('.sl-nav-sl1 .slide').click(function(event) {
		/* Act on the event */
		 $('.sl-1').slick('slickGoTo',this.dataset.slickIndex);
	});
	

	$(window).resize();
	$(window).scroll();
});
$('button.btn.m-btn').click(function(event) {
	/* Act on the event */
	$('.t-menu').toggleClass('active');
	$(this).toggleClass('active');
});
$('.t-menu a').click(function(event) {
	/* Act on the event */
	event.preventDefault();
	$(this).goto();
});
$('.sscrool').click(function(event) {
	event.preventDefault();
	$(this).goto();	
});

$(window).on('resize', function(event) {
	console.log($(window).width());
	if($(window).width()<=750){
		$('.js-marg').css('margin-left','0px');
		$('.ell-h1 .dec').css('margin-top','0px');
		$('.js-p-he').each(function(index, el) {
			$(this).find('.js-he').height('auto');
		});
		$('.ell-header').each(function(index, el) {
			
			var b = $(this).find('.bod');
			var p = $(this).find('.point');
			b.width('auto');
			b.height('auto');
			b.css({
				'margin-left' : '0px',
				'margin-top': '0px'
			});
			p.removeClass('act');
		});
	}else{
		

		$('.js-marg').css('margin-left','-'+$($('.container')[0]).css('margin-left'));
		$('.ell-h1 .dec').css('margin-top','-'+$($('.container')[0]).css('margin-left'));
		$('.js-p-he').each(function(index, el) {
			$(this).sh('.js-he');
		});
		$('.ell-header').each(function(index, el) {
			var b = $(this).find('.bod');
			var p = $(this).find('.point');
			p.addClass('act');
			b.width(b.height());
			b.height(b.width());
			b.css({
				'margin-top' : '-'+b.width()/2+'px',
				'margin-left': '-'+b.height()/2+'px'
			});
			$(this).css({
				'min-height': b.width()+'px',
			});
		});
	}
	$('.tblock').css({
		'margin-top': $('.head').innerHeight()+'px'
	});
	
});
$(window).scroll(function(event) {
	/* Act on the event */
	$('.js-scrl').each(function(index, el) {
		if( $(window).scrollTop()+$('.head').innerHeight()+1 >= $(this).offset().top) {
			$('.t-menu .active').removeClass('active');
			$('a[href="#'+this.id+'"]').addClass('active');
		}
	});
	if($(window).scrollTop()+$(window).height()  == $(document).height()){
		$('.t-menu .active').removeClass('active');
		$('a[href="#block10"]').addClass('active');
	}
});
$.prototype.sh = function(ch) {
	this.find(ch).height('auto');
	this.find(ch).height(this.height())
};
$.prototype.goto = function(first_argument) {
	var el = $(this.attr('href'));
	$('body,html').animate({
		scrollTop: ($(el).offset().top-$('.head').innerHeight())}, 1500);
};